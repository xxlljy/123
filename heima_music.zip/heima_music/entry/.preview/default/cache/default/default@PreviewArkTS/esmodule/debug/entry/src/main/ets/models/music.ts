// interface 主要用于描述对象的结构(作为类型)
export interface songItemType {
    img: string; // 歌曲封面
    name: string; // 歌曲名称
    author: string; // 歌曲作者
    url: string; // 歌曲地址
    id: string; // 歌曲id
}
// class 也可描述对象的结构(作为类型使用)，class 可通过 new 创建新对象
export class songItemTypeModel implements songItemType {
    img: string = '';
    name: string = '';
    author: string = '';
    url: string = '';
    id: string = '';
    constructor(model: songItemType) {
        this.img = model.img;
        this.name = model.name;
        this.author = model.author;
        this.url = model.url;
        this.id = model.id;
    }
}
