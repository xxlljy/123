if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Demo_Params {
    message?: string;
}
class Demo extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__message = new ObservedPropertySimplePU('Hello World', this, "message");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Demo_Params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
    }
    updateStateVars(params: Demo_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __message: ObservedPropertySimplePU<string>;
    get message() {
        return this.__message.get();
    }
    set message(newValue: string) {
        this.__message.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 列容器
            // { space: 10 }  设置列容器内，组件的间隔
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/Demo.ets(9:5)", "entry");
            // 列容器
            // { space: 10 }  设置列容器内，组件的间隔
            Column.height('100%');
            // 列容器
            // { space: 10 }  设置列容器内，组件的间隔
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 图片组件
            Image.create({ "id": 16777228, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Demo.ets(11:7)", "entry");
            // 图片组件
            Image.height(200);
            // 图片组件
            Image.margin({ top: 20 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 文本组件
            Text.create('帝师县令');
            Text.debugLine("entry/src/main/ets/pages/Demo.ets(15:7)", "entry");
            // 文本组件
            Text.fontWeight(600);
            // 文本组件
            Text.fontSize(30);
        }, Text);
        // 文本组件
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('202万字');
            Text.debugLine("entry/src/main/ets/pages/Demo.ets(18:7)", "entry");
            Text.fontSize(14);
            Text.fontColor('#999');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('兵荒马乱的世道，赵康一朝穿越成乾国九品县令。胸无大志的他并不想争霸天下，只想当个混吃等死，为非作歹的土皇帝。于是，在元江县出现了许多奇奇怪怪的东西，老八洗浴城、二狗麻将馆、张三养生店.....直到有一天女帝微服私访 元江县.....');
            Text.debugLine("entry/src/main/ets/pages/Demo.ets(21:7)", "entry");
            Text.fontColor('#333');
            Text.fontSize(16);
            Text.lineHeight(24);
            Text.padding({ left: 20, right: 20 });
        }, Text);
        Text.pop();
        // 列容器
        // { space: 10 }  设置列容器内，组件的间隔
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Demo";
    }
}
registerNamedRoute(() => new Demo(undefined, {}), "", { bundleName: "com.itheima.hm_music", moduleName: "entry", pagePath: "pages/Demo", pageFullPath: "entry/src/main/ets/pages/Demo", integratedHsp: "false" });
