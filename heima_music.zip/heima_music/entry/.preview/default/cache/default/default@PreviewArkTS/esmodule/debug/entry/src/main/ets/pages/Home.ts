if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Home_Params {
    message?: string;
}
class Home extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__message = new ObservedPropertySimplePU('Hello World～'
        // UI 描述，声明式 UI，建议设置-保存时自动格式化
        , this, "message");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Home_Params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
    }
    updateStateVars(params: Home_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 装饰器，组件状态
    private __message: ObservedPropertySimplePU<string>;
    get message() {
        return this.__message.get();
    }
    set message(newValue: string) {
        this.__message.set(newValue);
    }
    // UI 描述，声明式 UI，建议设置-保存时自动格式化
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 全局组件(大写开头的)
            // Column 列容器组件 { } 放容器组件内容
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Home.ets(14:5)", "entry");
            // 全局组件(大写开头的)
            // Column 列容器组件 { } 放容器组件内容
            Column.height('100%');
            // 全局组件(大写开头的)
            // Column 列容器组件 { } 放容器组件内容
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // Row 行容器组件 { } 放容器组件内容
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Home.ets(16:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // Text 文本组件，也可作为容器 { }，可以放 Span 组件
            Text.create('Hello 1');
            Text.debugLine("entry/src/main/ets/pages/Home.ets(18:9)", "entry");
        }, Text);
        // Text 文本组件，也可作为容器 { }，可以放 Span 组件
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('Hello 2');
            Text.debugLine("entry/src/main/ets/pages/Home.ets(19:9)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('Hello 3');
            Text.debugLine("entry/src/main/ets/pages/Home.ets(20:9)", "entry");
        }, Text);
        Text.pop();
        // Row 行容器组件 { } 放容器组件内容
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('你好，鸿蒙世界1');
            Text.debugLine("entry/src/main/ets/pages/Home.ets(23:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('你好，鸿蒙世界2');
            Text.debugLine("entry/src/main/ets/pages/Home.ets(24:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('你好，鸿蒙世界3');
            Text.debugLine("entry/src/main/ets/pages/Home.ets(25:7)", "entry");
            Text.fontColor(Color.Blue);
            Text.fontSize(30);
            Text.fontWeight(900);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Home.ets(29:7)", "entry");
            Row.width(100);
            Row.height(100);
            Row.backgroundColor('#c819b7e7');
        }, Row);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 图片组件
            // 图片格式支持 png、jpg、jpeg、bmp、svg、webp、gif和heif类型的图片格式。
            // $r() 用于引入本地 resources 文件夹中的资源
            Image.create({ "id": 16777219, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Home.ets(40:7)", "entry");
            // 图片组件
            // 图片格式支持 png、jpg、jpeg、bmp、svg、webp、gif和heif类型的图片格式。
            // $r() 用于引入本地 resources 文件夹中的资源
            Image.width(100);
            // 图片组件
            // 图片格式支持 png、jpg、jpeg、bmp、svg、webp、gif和heif类型的图片格式。
            // $r() 用于引入本地 resources 文件夹中的资源
            Image.backgroundColor('#000');
        }, Image);
        // 全局组件(大写开头的)
        // Column 列容器组件 { } 放容器组件内容
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Home";
    }
}
registerNamedRoute(() => new Home(undefined, {}), "", { bundleName: "com.itheima.hm_music", moduleName: "entry", pagePath: "pages/Home", pageFullPath: "entry/src/main/ets/pages/Home", integratedHsp: "false" });
