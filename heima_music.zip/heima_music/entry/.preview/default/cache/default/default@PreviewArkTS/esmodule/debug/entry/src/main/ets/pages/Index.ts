if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    // 自定义数据，string [] 表示 字符串数组 (数组的每一项都是字符串)
    // tabData: string[] = ['推荐', '发现', '动态', '我的']
    // 对象数组，数组的每一项，都是对象
    tabData?: TabClass[];
    isActive?: string;
}
import Find from "@bundle:com.itheima.hm_music/entry/ets/views/Find";
import Mine from "@bundle:com.itheima.hm_music/entry/ets/views/Mine";
import Moment from "@bundle:com.itheima.hm_music/entry/ets/views/Moment";
import Recommend from "@bundle:com.itheima.hm_music/entry/ets/views/Recommend";
interface TabClass {
    icon: Resource; // 图标，类型为 Resource 资源
    text: string; // 文本
    name: string; // 用于切换的标识
}
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.tabData = [
            { icon: { "id": 16777248, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" }, text: '推荐', name: 'recommend' },
            { icon: { "id": 16777241, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" }, text: '发现', name: 'find' },
            { icon: { "id": 16777260, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" }, text: '动态', name: 'moment' },
            { icon: { "id": 16777237, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" }, text: '我的', name: 'mine' },
        ];
        this.__isActive = new ObservedPropertySimplePU('recommend'
        // @Builder 自定义结构(可以理解为一个特殊的函数，用于构建结构)
        , this, "isActive");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.tabData !== undefined) {
            this.tabData = params.tabData;
        }
        if (params.isActive !== undefined) {
            this.isActive = params.isActive;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__isActive.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__isActive.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 自定义数据，string [] 表示 字符串数组 (数组的每一项都是字符串)
    // tabData: string[] = ['推荐', '发现', '动态', '我的']
    // 对象数组，数组的每一项，都是对象
    private tabData: TabClass[];
    // @State 定义状态，状态更新，视图界面也会更新
    private __isActive: ObservedPropertySimplePU<string>;
    get isActive() {
        return this.__isActive.get();
    }
    set isActive(newValue: string) {
        this.__isActive.set(newValue);
    }
    // @Builder 自定义结构(可以理解为一个特殊的函数，用于构建结构)
    tabBarBuilder(item: TabClass, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 5 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(30:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(item.icon);
            Image.debugLine("entry/src/main/ets/pages/Index.ets(31:7)", "entry");
            Image.height(24);
            Image.fillColor(this.isActive === item.name ? '#e4608b' : '#6da8a5');
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.text);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(34:7)", "entry");
            Text.fontSize(14);
            Text.fontColor(this.isActive === item.name ? '#e4608b' : '#6da8a5');
        }, Text);
        Text.pop();
        Column.pop();
    }
    // UI 描述
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // Tabs 大容器，barPosition 可以调整按钮的位置
            Tabs.create({ barPosition: BarPosition.End });
            Tabs.debugLine("entry/src/main/ets/pages/Index.ets(43:5)", "entry");
            // Tabs 大容器，barPosition 可以调整按钮的位置
            Tabs.backgroundColor('#3b3f42');
            // Tabs 大容器，barPosition 可以调整按钮的位置
            Tabs.onChange((index: number) => {
                // 控制台日志打印，第一个参数必须是字符串，后面的参数会自动 toString 转换成字符串打印
                // console.log('字符串标记', index)
                // 通过弹窗方式看数据，推荐使用
                // AlertDialog.show({ message: index.toString() })
                // 如果是查看对象，可通过 JSON.stringify(对象, null, 2) 把对象转换成 JSON 字符串
                // AlertDialog.show({ message: JSON.stringify(this.tabData[index], null, 2) })
                // @State 状态改变，视图能自动更新
                this.isActive = this.tabData[index].name;
            });
        }, Tabs);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // // TabContent   切换的内容
            // TabContent() {
            //   // 切换的内容可以放置其他组件
            //   Text('推荐视图')
            // }
            // .tabBar('推荐') // 用于切换的按钮
            //
            // TabContent() {
            //   Text('发现视图')
            // }
            // .tabBar('发现')
            // ForEach 循环渲染
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    TabContent.create(() => {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            If.create();
                            // + 号连接字符串
                            // Text(item.text + '视图')
                            // if 条件渲染
                            if (item.name === 'recommend') {
                                this.ifElseBranchUpdateFunction(0, () => {
                                    {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            if (isInitialRender) {
                                                let componentCall = new Recommend(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 64, col: 13 });
                                                ViewPU.create(componentCall);
                                                let paramsLambda = () => {
                                                    return {};
                                                };
                                                componentCall.paramsGenerator_ = paramsLambda;
                                            }
                                            else {
                                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                                            }
                                        }, { name: "Recommend" });
                                    }
                                });
                            }
                            else if (item.name === 'find') {
                                this.ifElseBranchUpdateFunction(1, () => {
                                    {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            if (isInitialRender) {
                                                let componentCall = new Find(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 66, col: 13 });
                                                ViewPU.create(componentCall);
                                                let paramsLambda = () => {
                                                    return {};
                                                };
                                                componentCall.paramsGenerator_ = paramsLambda;
                                            }
                                            else {
                                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                                            }
                                        }, { name: "Find" });
                                    }
                                });
                            }
                            else if (item.name === 'moment') {
                                this.ifElseBranchUpdateFunction(2, () => {
                                    {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            if (isInitialRender) {
                                                let componentCall = new Moment(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 68, col: 13 });
                                                ViewPU.create(componentCall);
                                                let paramsLambda = () => {
                                                    return {};
                                                };
                                                componentCall.paramsGenerator_ = paramsLambda;
                                            }
                                            else {
                                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                                            }
                                        }, { name: "Moment" });
                                    }
                                });
                            }
                            else if (item.name === 'mine') {
                                this.ifElseBranchUpdateFunction(3, () => {
                                    {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            if (isInitialRender) {
                                                let componentCall = new Mine(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 70, col: 13 });
                                                ViewPU.create(componentCall);
                                                let paramsLambda = () => {
                                                    return {};
                                                };
                                                componentCall.paramsGenerator_ = paramsLambda;
                                            }
                                            else {
                                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                                            }
                                        }, { name: "Mine" });
                                    }
                                });
                            }
                            else {
                                this.ifElseBranchUpdateFunction(4, () => {
                                });
                            }
                        }, If);
                        If.pop();
                    });
                    TabContent.padding({ top: 38 });
                    TabContent.backgroundColor('#131215');
                    TabContent.tabBar({ builder: () => {
                            this.tabBarBuilder.call(this, item);
                        } });
                    TabContent.debugLine("entry/src/main/ets/pages/Index.ets(59:9)", "entry");
                }, TabContent);
                TabContent.pop();
            };
            this.forEachUpdateFunction(elmtId, this.tabData, forEachItemGenFunction);
        }, ForEach);
        // // TabContent   切换的内容
        // TabContent() {
        //   // 切换的内容可以放置其他组件
        //   Text('推荐视图')
        // }
        // .tabBar('推荐') // 用于切换的按钮
        //
        // TabContent() {
        //   Text('发现视图')
        // }
        // .tabBar('发现')
        // ForEach 循环渲染
        ForEach.pop();
        // Tabs 大容器，barPosition 可以调整按钮的位置
        Tabs.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.itheima.hm_music", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false" });
