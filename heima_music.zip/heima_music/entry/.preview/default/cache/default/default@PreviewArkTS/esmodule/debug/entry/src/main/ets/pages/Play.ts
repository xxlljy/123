if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Play_Params {
    panelHeight?: string;
    songs?: songItemType[];
    playState?: songItemType;
}
import type { songItemType } from '../models/music';
import AvPlayerManager from "@bundle:com.itheima.hm_music/entry/ets/utils/AvPlayerManager";
class Play extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__panelHeight = new ObservedPropertySimplePU('0%', this, "panelHeight");
        this.songs = [
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/0.jpg',
                name: '直到世界的尽头',
                author: 'WANDS',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/0.m4a',
                id: '0000'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/1.jpg',
                name: '画',
                author: '赵磊',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/1.mp3',
                id: '0001'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/2.jpg',
                name: 'Sweet Dreams',
                author: 'TPaul Sax / Eurythmics',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/2.mp3',
                id: '0002'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/3.jpg',
                name: '奢香夫人',
                author: '凤凰传奇',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/3.m4a',
                id: '0003'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/4.jpg',
                name: '空心',
                author: '光泽',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/4.mp3',
                id: '0004'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/5.jpg',
                name: '反转地球',
                author: '潘玮柏',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/5.mp3',
                id: '0005'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/6.jpg',
                name: 'No.9',
                author: 'T-ara',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/6.m4a',
                id: '0006'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/7.jpg',
                name: '孤独',
                author: 'G.E.M.邓紫棋',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/7.m4a',
                id: '0007'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/8.jpg',
                name: 'Lose Control',
                author: 'Hedley',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/8.m4a',
                id: '0008'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/9.jpg',
                name: '倩女幽魂',
                author: '张国荣',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/9.m4a',
                id: '0009'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/10.jpg',
                name: '北京北京',
                author: '汪峰',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/10.m4a',
                id: '0010'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/11.jpg',
                name: '苦笑',
                author: '汪苏泷',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/11.mp3',
                id: '0011'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/12.jpg',
                name: '一生所爱',
                author: '卢冠廷 / 莫文蔚',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/12.m4a',
                id: '0012'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/13.jpg',
                name: '月半小夜曲',
                author: '李克勤',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/13.mp3',
                id: '0013'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/14.jpg',
                name: 'Rolling in the Deep',
                author: 'Adele',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/14.m4a',
                id: '0014'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/15.jpg',
                name: '海阔天空',
                author: 'Beyond',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/15.m4a',
                id: '0015'
            }
        ];
        this.__playState = new ObservedPropertyObjectPU(this.songs[0], this, "playState");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Play_Params) {
        if (params.panelHeight !== undefined) {
            this.panelHeight = params.panelHeight;
        }
        if (params.songs !== undefined) {
            this.songs = params.songs;
        }
        if (params.playState !== undefined) {
            this.playState = params.playState;
        }
    }
    updateStateVars(params: Play_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__panelHeight.purgeDependencyOnElmtId(rmElmtId);
        this.__playState.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__panelHeight.aboutToBeDeleted();
        this.__playState.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __panelHeight: ObservedPropertySimplePU<string>;
    get panelHeight() {
        return this.__panelHeight.get();
    }
    set panelHeight(newValue: string) {
        this.__panelHeight.set(newValue);
    }
    private songs: songItemType[];
    // 当前播放的歌曲
    private __playState: ObservedPropertyObjectPU<songItemType>;
    get playState() {
        return this.__playState.get();
    }
    set playState(newValue: songItemType) {
        this.__playState.set(newValue);
    }
    deleteButton(index: number, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('删除');
            Button.debugLine("entry/src/main/ets/pages/Play.ets(129:5)", "entry");
            Button.backgroundColor('#ec5c87');
            Button.fontColor('#fff');
            Button.width(80);
            Button.height('100%');
            Button.type(ButtonType.Normal);
        }, Button);
        Button.pop();
    }
    number2time(number: number) {
        // 毫秒 → 秒 → 分+秒; 先判断是否大于1分钟
        if (number >= 60 * 1000) {
            const s = Math.ceil(number / 1000 % 60);
            const m = Math.floor(number / 1000 / 60);
            const second = s.toString()
                .padStart(2, '0');
            const minute = m.toString()
                .padStart(2, '0');
            return minute + ':' + second;
        }
        else {
            const s = Math.ceil(number / 1000 % 60);
            const second = s.toString()
                .padStart(2, '0');
            return '00:' + second;
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.Bottom });
            Stack.debugLine("entry/src/main/ets/pages/Play.ets(157:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
            Stack.backgroundColor(Color.Transparent);
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 播放
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/Play.ets(159:7)", "entry");
            // 播放
            Stack.width('100%');
            // 播放
            Stack.height('100%');
            // 播放
            Stack.backgroundColor(Color.Transparent);
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 变色背景
            Image.create(this.playState.img);
            Image.debugLine("entry/src/main/ets/pages/Play.ets(161:9)", "entry");
            // 变色背景
            Image.width('100%');
            // 变色背景
            Image.height('100%');
            // 变色背景
            Image.blur(1000);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 内容
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Play.ets(166:9)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // //   播放界面
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Play.ets(168:11)", "entry");
            // //   播放界面
            Column.layoutWeight(1);
            // //   播放界面
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 图片
            Stack.create({ alignContent: Alignment.Top });
            Stack.debugLine("entry/src/main/ets/pages/Play.ets(170:13)", "entry");
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Play.ets(171:15)", "entry");
            Row.margin({
                top: 50
            });
            Row.width('90%');
            Row.aspectRatio(1);
            Row.justifyContent(FlexAlign.Center);
            Row.padding(24);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Play.ets(172:17)", "entry");
            Row.backgroundImage({ "id": 16777244, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
            Row.backgroundImageSize(ImageSize.Cover);
            Row.justifyContent(FlexAlign.Center);
            Row.width('100%');
            Row.borderRadius(400);
            Row.clip(true);
            Row.aspectRatio(1);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(this.playState.img);
            Image.debugLine("entry/src/main/ets/pages/Play.ets(173:19)", "entry");
            Image.width('70%');
            Image.borderRadius(400);
        }, Image);
        Row.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 唱针
            Image.create({ "id": 16777262, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Play.ets(194:15)", "entry");
            Context.animation({
                duration: 500
            });
            // 唱针
            Image.width(200);
            // 唱针
            Image.aspectRatio(1);
            // 唱针
            Image.rotate({
                angle: -55,
                centerX: 100,
                centerY: 30
            });
            Context.animation(null);
        }, Image);
        // 图片
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 歌曲信息
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/Play.ets(208:13)", "entry");
            // 歌曲信息
            Stack.layoutWeight(1);
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 第一个
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/Play.ets(210:15)", "entry");
            // 第一个
            Column.layoutWeight(1);
            // 第一个
            Column.justifyContent(FlexAlign.Center);
            // 第一个
            Column.zIndex(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.playState.name);
            Text.debugLine("entry/src/main/ets/pages/Play.ets(211:17)", "entry");
            Text.fontSize(28);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor('#4bb0c4');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.playState.author);
            Text.debugLine("entry/src/main/ets/pages/Play.ets(215:17)", "entry");
            Text.fontSize(18);
            Text.fontColor('#4bb0c4');
        }, Text);
        Text.pop();
        // 第一个
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 第二个
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/Play.ets(224:15)", "entry");
            // 第二个
            Column.layoutWeight(1);
            // 第二个
            Column.justifyContent(FlexAlign.Center);
            // 第二个
            Column.zIndex(2);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.playState.name);
            Text.debugLine("entry/src/main/ets/pages/Play.ets(225:17)", "entry");
            Text.fontSize(28);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor('#ec5c87');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.playState.author);
            Text.debugLine("entry/src/main/ets/pages/Play.ets(229:17)", "entry");
            Text.fontSize(18);
            Text.fontColor('#ec5c87');
        }, Text);
        Text.pop();
        // 第二个
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 第三个
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/Play.ets(238:15)", "entry");
            // 第三个
            Column.layoutWeight(1);
            // 第三个
            Column.justifyContent(FlexAlign.Center);
            // 第三个
            Column.zIndex(3);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.playState.name);
            Text.debugLine("entry/src/main/ets/pages/Play.ets(239:17)", "entry");
            Text.fontSize(28);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Color.White);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.playState.author);
            Text.debugLine("entry/src/main/ets/pages/Play.ets(243:17)", "entry");
            Text.fontSize(18);
            Text.fontColor(Color.White);
        }, Text);
        Text.pop();
        // 第三个
        Column.pop();
        // 歌曲信息
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 操作
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Play.ets(254:13)", "entry");
            // 操作
            Row.width('100%');
            // 操作
            Row.justifyContent(FlexAlign.SpaceAround);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Badge.create({ value: '99+', style: { badgeSize: 12, badgeColor: '#45CCCCCC', borderWidth: 0 } });
            Badge.debugLine("entry/src/main/ets/pages/Play.ets(255:15)", "entry");
        }, Badge);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777254, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Play.ets(256:17)", "entry");
            Image.fillColor(Color.White);
            Image.width(24);
        }, Image);
        Badge.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Badge.create({ value: '10W', style: { badgeSize: 12, badgeColor: '#45cccccc', borderWidth: 0 } });
            Badge.debugLine("entry/src/main/ets/pages/Play.ets(261:15)", "entry");
        }, Badge);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777243, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Play.ets(262:17)", "entry");
            Image.fillColor(Color.White);
            Image.width(18);
        }, Image);
        Badge.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Badge.create({ value: 'hot', style: { badgeSize: 12, badgeColor: '#a8ff3131', borderWidth: 0 } });
            Badge.debugLine("entry/src/main/ets/pages/Play.ets(267:15)", "entry");
        }, Badge);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777242, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Play.ets(268:17)", "entry");
            Image.fillColor(Color.White);
            Image.width(24);
        }, Image);
        Badge.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Badge.create({ value: 'vip', style: { badgeSize: 12, badgeColor: '#b7efd371', borderWidth: 0 } });
            Badge.debugLine("entry/src/main/ets/pages/Play.ets(273:15)", "entry");
        }, Badge);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777234, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Play.ets(274:17)", "entry");
            Image.fillColor(Color.White);
            Image.width(24);
        }, Image);
        Badge.pop();
        // 操作
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 播放
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Play.ets(283:13)", "entry");
            // 播放
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 进度条
            Row.create({ space: 4 });
            Row.debugLine("entry/src/main/ets/pages/Play.ets(285:15)", "entry");
            // 进度条
            Row.width('100%');
            // 进度条
            Row.padding(24);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("00:00");
            Text.debugLine("entry/src/main/ets/pages/Play.ets(286:17)", "entry");
            Text.fontSize(12);
            Text.fontColor(Color.White);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Slider.create({
                value: 0,
                min: 0,
                max: 0
            });
            Slider.debugLine("entry/src/main/ets/pages/Play.ets(289:17)", "entry");
            Slider.layoutWeight(1);
            Slider.blockColor(Color.White);
            Slider.selectedColor(Color.White);
            Slider.trackColor('#ccc5c5c5');
            Slider.trackThickness(2);
        }, Slider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("00:00");
            Text.debugLine("entry/src/main/ets/pages/Play.ets(299:17)", "entry");
            Text.fontSize(12);
            Text.fontColor(Color.White);
        }, Text);
        Text.pop();
        // 进度条
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 切换
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Play.ets(307:15)", "entry");
            // 切换
            Row.width('100%');
            // 切换
            Row.padding({
                bottom: 24
            });
            // 切换
            Row.justifyContent(FlexAlign.SpaceAround);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777257, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Play.ets(308:17)", "entry");
            Image.fillColor(Color.White);
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777259, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Play.ets(312:17)", "entry");
            Image.fillColor(Color.White);
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 播放按钮
            Image.create({ "id": 16777240, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Play.ets(317:17)", "entry");
            // 播放按钮
            Image.fillColor(Color.White);
            // 播放按钮
            Image.width(50);
            // 播放按钮
            Image.onClick(() => {
                AvPlayerManager.pause();
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 下一首
            Image.create({ "id": 16777235, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Play.ets(324:17)", "entry");
            // 下一首
            Image.fillColor(Color.White);
            // 下一首
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 播放列表
            Image.create({ "id": 16777252, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Play.ets(328:17)", "entry");
            // 播放列表
            Image.fillColor(Color.White);
            // 播放列表
            Image.width(30);
        }, Image);
        // 切换
        Row.pop();
        // 播放
        Column.pop();
        // //   播放界面
        Column.pop();
        // 内容
        Column.pop();
        // 播放
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 列表
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Play.ets(349:7)", "entry");
            Context.animation({
                duration: 300
            });
            // 列表
            Column.height(this.panelHeight);
            Context.animation(null);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Play.ets(350:9)", "entry");
            Column.width('100%');
            Column.layoutWeight(1);
            Column.onClick(() => {
                this.panelHeight = '0%';
            });
        }, Column);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Play.ets(359:9)", "entry");
            Column.height(400);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Play.ets(360:11)", "entry");
            Row.width('100%');
            Row.backgroundColor('#ff353333');
            Row.padding(8);
            Row.border({
                width: { bottom: 1 },
                color: '#12ec5c87'
            });
            Row.borderRadius({
                topLeft: 4,
                topRight: 4
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Play.ets(361:13)", "entry");
            Row.width(50);
            Row.aspectRatio(1);
            Row.justifyContent(FlexAlign.Center);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777239, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Play.ets(362:15)", "entry");
            Image.width(20);
            Image.fillColor('#ff5186');
        }, Image);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 8 });
            Row.debugLine("entry/src/main/ets/pages/Play.ets(370:13)", "entry");
            Row.layoutWeight(1);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`播放列表 (0)`);
            Text.debugLine("entry/src/main/ets/pages/Play.ets(371:15)", "entry");
            Text.fontColor(Color.White);
            Text.fontSize(14);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777231, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Play.ets(377:13)", "entry");
            Image.fillColor('#ffa49a9a');
            Image.width(24);
            Image.height(24);
            Image.margin({ right: 16 });
            Image.onClick(() => {
                this.panelHeight = '0%';
            });
        }, Image);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 播放列表
            List.create();
            List.debugLine("entry/src/main/ets/pages/Play.ets(399:11)", "entry");
            // 播放列表
            List.layoutWeight(1);
            // 播放列表
            List.backgroundColor('#ff353333');
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.swipeAction({
                            end: this.deleteButton.bind(this, index)
                        });
                        ListItem.border({
                            width: { bottom: 1 },
                            color: '#12ec5c87'
                        });
                        ListItem.debugLine("entry/src/main/ets/pages/Play.ets(401:15)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Row.create();
                            Row.debugLine("entry/src/main/ets/pages/Play.ets(402:17)", "entry");
                            Row.alignItems(VerticalAlign.Center);
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Row.create();
                            Row.debugLine("entry/src/main/ets/pages/Play.ets(403:19)", "entry");
                            Row.width(50);
                            Row.aspectRatio(1);
                            Row.justifyContent(FlexAlign.Center);
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create((index + 1).toString());
                            Text.debugLine("entry/src/main/ets/pages/Play.ets(404:21)", "entry");
                            Text.fontColor('#ffa49a9a');
                        }, Text);
                        Text.pop();
                        Row.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            // 列表
                            Row.create({ space: 10 });
                            Row.debugLine("entry/src/main/ets/pages/Play.ets(412:19)", "entry");
                            // 列表
                            Row.layoutWeight(1);
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Column.create();
                            Column.debugLine("entry/src/main/ets/pages/Play.ets(413:21)", "entry");
                            Column.layoutWeight(1);
                            Column.alignItems(HorizontalAlign.Start);
                            Column.justifyContent(FlexAlign.Center);
                        }, Column);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.name);
                            Text.debugLine("entry/src/main/ets/pages/Play.ets(414:23)", "entry");
                            Text.fontSize(14);
                            Text.fontColor('#ffa49a9a');
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.author);
                            Text.debugLine("entry/src/main/ets/pages/Play.ets(417:23)", "entry");
                            Text.fontSize(12);
                            Text.fontColor(Color.Gray);
                        }, Text);
                        Text.pop();
                        Column.pop();
                        // 列表
                        Row.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Image.create({ "id": 16777230, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
                            Image.debugLine("entry/src/main/ets/pages/Play.ets(427:19)", "entry");
                            Image.width(24);
                            Image.height(24);
                            Image.margin({ right: 16 });
                            Image.fillColor(Color.Gray);
                        }, Image);
                        Row.pop();
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.songs, forEachItemGenFunction, undefined, true, false);
        }, ForEach);
        ForEach.pop();
        // 播放列表
        List.pop();
        Column.pop();
        // 列表
        Column.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Play";
    }
}
registerNamedRoute(() => new Play(undefined, {}), "", { bundleName: "com.itheima.hm_music", moduleName: "entry", pagePath: "pages/Play", pageFullPath: "entry/src/main/ets/pages/Play", integratedHsp: "false" });
