if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Start_Params {
    message?: string;
}
import router from "@ohos:router";
class Start extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__message = new ObservedPropertySimplePU('Hello World', this, "message");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Start_Params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
    }
    updateStateVars(params: Start_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __message: ObservedPropertySimplePU<string>;
    get message() {
        return this.__message.get();
    }
    set message(newValue: string) {
        this.__message.set(newValue);
    }
    // 页面生命周期，在特定时机自动执行的函数
    // 在页面加载时，build 界面构建前，自动执行 aboutToAppear 函数
    aboutToAppear(): void {
        // 开启定时器，5000 毫秒后执行函数内的业务代码
        setTimeout(() => {
            router.replaceUrl({ url: 'pages/Index' });
        }, 5000);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // Stack 层叠布局，可通过 alignContent 设置容器内组件对齐方式
            Stack.create({ alignContent: Alignment.TopEnd });
            Stack.debugLine("entry/src/main/ets/pages/Start.ets(20:5)", "entry");
            // Stack 层叠布局，可通过 alignContent 设置容器内组件对齐方式
            Stack.height('100%');
            // Stack 层叠布局，可通过 alignContent 设置容器内组件对齐方式
            Stack.width('100%');
            // Stack 层叠布局，可通过 alignContent 设置容器内组件对齐方式
            Stack.expandSafeArea();
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 图片
            Image.create({ "id": 16777238, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Start.ets(22:7)", "entry");
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 按钮
            Button.createWithLabel('跳过');
            Button.debugLine("entry/src/main/ets/pages/Start.ets(24:7)", "entry");
            // 按钮
            Button.margin(10);
            // 按钮
            Button.onClick(() => {
                // onClick 点击事件，传入箭头函数 ()=>{}
                // router         路由模块，负责页面跳转
                // .pushUrl()     把新页面加入到路由栈中，可以点击后退返回上一页
                // router.pushUrl({ url: 'pages/Demo' })
                // .replaceUrl()  把页面替换成新页面，不可返回原页面，原页面被销毁
                router.replaceUrl({ url: 'pages/Index' });
            });
        }, Button);
        // 按钮
        Button.pop();
        // Stack 层叠布局，可通过 alignContent 设置容器内组件对齐方式
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Start";
    }
}
registerNamedRoute(() => new Start(undefined, {}), "", { bundleName: "com.itheima.hm_music", moduleName: "entry", pagePath: "pages/Start", pageFullPath: "entry/src/main/ets/pages/Start", integratedHsp: "false" });
