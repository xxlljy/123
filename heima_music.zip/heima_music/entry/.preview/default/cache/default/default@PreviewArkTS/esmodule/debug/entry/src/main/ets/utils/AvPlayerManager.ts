import media from "@ohos:multimedia.media";
import type { songItemType } from '../models/music';
// ArkTS(ets) 语法是 TypeScript 语法的扩展
// export default  默认导出
// export          导出多个
// static          静态
class AvPlayerManager {
    // 播放器对象
    static player: media.AVPlayer | null = null;
    // 初始化播放器
    static async init() {
        // async await 提取 Promise 成功的结果
        // const player = await media.createAVPlayer()
        // 没有 player 的情况下才创建
        if (!AvPlayerManager.player) {
            // 创建 AVPlayer 播放器，并保存到类中
            AvPlayerManager.player = await media.createAVPlayer();
            // 监听播放器状态变化
            AvPlayerManager.player.on('stateChange', (state: media.AVPlayerState) => {
                if (state === 'initialized') {
                    // 初始化完成，调用 prepare 准备
                    AvPlayerManager.player?.prepare();
                }
                else if (state === 'prepared') {
                    // 准备好了，调用 play 播放
                    AvPlayerManager.player?.play();
                }
            });
        }
    }
    // 单曲播放
    static singPlay(item: songItemType) {
        // !  非空断言
        // ?. 不能赋值，所以要改成 !.
        AvPlayerManager.player!.url = item.url;
    }
    // 暂停播放
    static pause() {
        // .pause() 暂停
        AvPlayerManager.player?.pause();
    }
}
// 默认导出一个播放器的类
export default AvPlayerManager;
