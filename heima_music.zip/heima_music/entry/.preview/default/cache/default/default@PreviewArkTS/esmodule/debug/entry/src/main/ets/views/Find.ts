if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Find_Params {
    songs?: songItemType[];
}
import type { songItemType } from '../models/music';
import router from "@ohos:router";
import AvPlayerManager from "@bundle:com.itheima.hm_music/entry/ets/utils/AvPlayerManager";
export default class Find extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__songs = new ObservedPropertyObjectPU([
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/0.jpg',
                name: '直到世界的尽头',
                author: 'WANDS',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/0.m4a',
                id: '0000'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/1.jpg',
                name: '画',
                author: '赵磊',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/1.mp3',
                id: '0001'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/2.jpg',
                name: 'Sweet Dreams',
                author: 'TPaul Sax / Eurythmics',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/2.mp3',
                id: '0002'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/3.jpg',
                name: '奢香夫人',
                author: '凤凰传奇',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/3.m4a',
                id: '0003'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/4.jpg',
                name: '空心',
                author: '光泽',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/4.mp3',
                id: '0004'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/5.jpg',
                name: '反转地球',
                author: '潘玮柏',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/5.mp3',
                id: '0005'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/6.jpg',
                name: 'No.9',
                author: 'T-ara',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/6.m4a',
                id: '0006'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/7.jpg',
                name: '孤独',
                author: 'G.E.M.邓紫棋',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/7.m4a',
                id: '0007'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/8.jpg',
                name: 'Lose Control',
                author: 'Hedley',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/8.m4a',
                id: '0008'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/9.jpg',
                name: '倩女幽魂',
                author: '张国荣',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/9.m4a',
                id: '0009'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/10.jpg',
                name: '北京北京',
                author: '汪峰',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/10.m4a',
                id: '0010'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/11.jpg',
                name: '苦笑',
                author: '汪苏泷',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/11.mp3',
                id: '0011'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/12.jpg',
                name: '一生所爱',
                author: '卢冠廷 / 莫文蔚',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/12.m4a',
                id: '0012'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/13.jpg',
                name: '月半小夜曲',
                author: '李克勤',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/13.mp3',
                id: '0013'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/14.jpg',
                name: 'Rolling in the Deep',
                author: 'Adele',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/14.m4a',
                id: '0014'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/15.jpg',
                name: '海阔天空',
                author: 'Beyond',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/15.m4a',
                id: '0015'
            }
        ], this, "songs");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Find_Params) {
        if (params.songs !== undefined) {
            this.songs = params.songs;
        }
    }
    updateStateVars(params: Find_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__songs.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__songs.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __songs: ObservedPropertyObjectPU<songItemType[]>;
    get songs() {
        return this.__songs.get();
    }
    set songs(newValue: songItemType[]) {
        this.__songs.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/views/Find.ets(125:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.padding(8);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('猜你喜欢');
            Text.debugLine("entry/src/main/ets/views/Find.ets(126:7)", "entry");
            Text.fontColor('#fff');
            Text.width('100%');
            Text.margin({ top: 10, bottom: 10 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create();
            List.debugLine("entry/src/main/ets/views/Find.ets(130:7)", "entry");
            List.width('100%');
            List.height('100%');
            List.layoutWeight(1);
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.debugLine("entry/src/main/ets/views/Find.ets(132:11)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Row.create({ space: 10 });
                            Row.debugLine("entry/src/main/ets/views/Find.ets(133:13)", "entry");
                            Row.width('100%');
                            Row.margin({ bottom: 10 });
                            Row.onClick(() => {
                                // 点击跳转到 Play 播放页
                                router.pushUrl({ url: 'pages/Play' });
                                // 调用播放器，播放当前点击的歌曲
                                AvPlayerManager.singPlay(item);
                            });
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Image.create(item.img);
                            Image.debugLine("entry/src/main/ets/views/Find.ets(134:15)", "entry");
                            Image.width(80);
                            Image.aspectRatio(1);
                            Image.borderRadius(8);
                        }, Image);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Column.create({ space: 15 });
                            Column.debugLine("entry/src/main/ets/views/Find.ets(138:15)", "entry");
                            Column.layoutWeight(1);
                        }, Column);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.name);
                            Text.debugLine("entry/src/main/ets/views/Find.ets(139:17)", "entry");
                            Text.fontColor('#fff');
                            Text.fontWeight(700);
                            Text.width('100%');
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Row.create({ space: 8 });
                            Row.debugLine("entry/src/main/ets/views/Find.ets(143:17)", "entry");
                            Row.width('100%');
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create('VIP');
                            Text.debugLine("entry/src/main/ets/views/Find.ets(144:19)", "entry");
                            Text.fontSize(14);
                            Text.fontColor('#bab128');
                            Text.border({ width: 1, color: '#bab128', radius: 12 });
                            Text.padding({
                                left: 5,
                                right: 5,
                                top: 3,
                                bottom: 3
                            });
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.author);
                            Text.debugLine("entry/src/main/ets/views/Find.ets(154:19)", "entry");
                            Text.fontColor('#808082');
                        }, Text);
                        Text.pop();
                        Row.pop();
                        Column.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Image.create({ "id": 16777230, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
                            Image.debugLine("entry/src/main/ets/views/Find.ets(161:15)", "entry");
                            Image.width(24);
                            Image.fillColor('#fff');
                        }, Image);
                        Row.pop();
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.songs, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
if (getPreviewComponentFlag()) {
    storePreviewComponents(1, "Find", new Find(undefined, {}));
    previewComponent();
}
else {
}
