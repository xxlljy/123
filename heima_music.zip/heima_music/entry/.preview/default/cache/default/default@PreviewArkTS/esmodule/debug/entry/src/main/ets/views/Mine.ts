if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface SongCard_Params {
    columnIndex?: number;
    showList?: songItemType[];
    songs?: songItemType[];
}
interface Mine_Params {
    columnList?: number[];
}
import { songItemTypeModel } from "@bundle:com.itheima.hm_music/entry/ets/models/music";
import type { songItemType } from "@bundle:com.itheima.hm_music/entry/ets/models/music";
export default class Mine extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.columnList = [0, 1, 2, 3];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Mine_Params) {
        if (params.columnList !== undefined) {
            this.columnList = params.columnList;
        }
    }
    updateStateVars(params: Mine_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private columnList: number[];
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/views/Mine.ets(9:5)", "entry");
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 背景
            Column.create();
            Column.debugLine("entry/src/main/ets/views/Mine.ets(11:7)", "entry");
            // 背景
            Column.scale({
                x: 1.15,
                y: 1.15,
                centerX: '50%',
                centerY: '0'
            });
            // 背景
            Column.height('75%');
            // 背景
            Column.width('100%');
            // 背景
            Column.backgroundColor('#000');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            GridRow.create({ gutter: 8 });
            GridRow.debugLine("entry/src/main/ets/views/Mine.ets(12:9)", "entry");
        }, GridRow);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    GridCol.create({ span: 3 });
                    GridCol.debugLine("entry/src/main/ets/views/Mine.ets(14:13)", "entry");
                }, GridCol);
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new SongCard(this, { columnIndex: item }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/views/Mine.ets", line: 15, col: 15 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {
                                    columnIndex: item
                                };
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                    }, { name: "SongCard" });
                }
                GridCol.pop();
            };
            this.forEachUpdateFunction(elmtId, this.columnList, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        GridRow.pop();
        // 背景
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 个人信息
            Column.create();
            Column.debugLine("entry/src/main/ets/views/Mine.ets(31:7)", "entry");
            // 个人信息
            Column.width('100%');
            // 个人信息
            Column.height('25%');
            // 个人信息
            Column.backgroundColor('#121215');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/views/Mine.ets(32:9)", "entry");
            Column.backgroundColor(Color.Black);
            Column.width(80);
            Column.aspectRatio(1);
            Column.borderRadius(80);
            Column.offset({ y: -40 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777251, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/views/Mine.ets(33:11)", "entry");
            Image.width('90%');
        }, Image);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 12 });
            Column.debugLine("entry/src/main/ets/views/Mine.ets(42:9)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 8 });
            Row.debugLine("entry/src/main/ets/views/Mine.ets(43:11)", "entry");
            Row.offset({ y: -15 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('黑马云音乐');
            Text.debugLine("entry/src/main/ets/views/Mine.ets(44:13)", "entry");
            Text.fontColor(Color.White);
            Text.fontSize(20);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777249, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/views/Mine.ets(47:13)", "entry");
            Image.width(40);
        }, Image);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/views/Mine.ets(52:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777258, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/views/Mine.ets(53:13)", "entry");
            Image.width(14);
            Image.fillColor('#ff23496b');
            Image.margin({ right: 4 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('00后');
            Text.debugLine("entry/src/main/ets/views/Mine.ets(57:13)", "entry");
            Text.fontColor('#555');
            Text.margin({ right: 12 });
            Text.fontSize(14);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('双子座');
            Text.debugLine("entry/src/main/ets/views/Mine.ets(61:13)", "entry");
            Text.fontColor('#555');
            Text.margin({ right: 12 });
            Text.fontSize(14);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('北京');
            Text.debugLine("entry/src/main/ets/views/Mine.ets(65:13)", "entry");
            Text.fontColor('#555');
            Text.margin({ right: 12 });
            Text.fontSize(14);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('歌龄·18年');
            Text.debugLine("entry/src/main/ets/views/Mine.ets(69:13)", "entry");
            Text.fontColor('#555');
            Text.margin({ right: 12 });
            Text.fontSize(14);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/views/Mine.ets(75:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('1 关注');
            Text.debugLine("entry/src/main/ets/views/Mine.ets(76:13)", "entry");
            Text.fontColor('#555');
            Text.margin({ right: 12 });
            Text.fontSize(14);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('100万 粉丝');
            Text.debugLine("entry/src/main/ets/views/Mine.ets(80:13)", "entry");
            Text.fontColor('#555');
            Text.margin({ right: 12 });
            Text.fontSize(14);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('1.67亿 赞');
            Text.debugLine("entry/src/main/ets/views/Mine.ets(84:13)", "entry");
            Text.fontColor('#555');
            Text.margin({ right: 12 });
            Text.fontSize(14);
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        // 个人信息
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class SongCard extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.columnIndex = 0;
        this.__showList = new ObservedPropertyObjectPU([], this, "showList");
        this.songs = [
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/0.jpg',
                name: '直到世界的尽头',
                author: 'WANDS',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/0.m4a',
                id: '0000'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/1.jpg',
                name: '画',
                author: '赵磊',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/1.mp3',
                id: '0001'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/2.jpg',
                name: 'Sweet Dreams',
                author: 'TPaul Sax / Eurythmics',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/2.mp3',
                id: '0002'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/3.jpg',
                name: '奢香夫人',
                author: '凤凰传奇',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/3.m4a',
                id: '0003'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/4.jpg',
                name: '空心',
                author: '光泽',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/4.mp3',
                id: '0004'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/5.jpg',
                name: '反转地球',
                author: '潘玮柏',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/5.mp3',
                id: '0005'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/6.jpg',
                name: 'No.9',
                author: 'T-ara',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/6.m4a',
                id: '0006'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/7.jpg',
                name: '孤独',
                author: 'G.E.M.邓紫棋',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/7.m4a',
                id: '0007'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/8.jpg',
                name: 'Lose Control',
                author: 'Hedley',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/8.m4a',
                id: '0008'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/9.jpg',
                name: '倩女幽魂',
                author: '张国荣',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/9.m4a',
                id: '0009'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/10.jpg',
                name: '北京北京',
                author: '汪峰',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/10.m4a',
                id: '0010'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/11.jpg',
                name: '苦笑',
                author: '汪苏泷',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/11.mp3',
                id: '0011'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/12.jpg',
                name: '一生所爱',
                author: '卢冠廷 / 莫文蔚',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/12.m4a',
                id: '0012'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/13.jpg',
                name: '月半小夜曲',
                author: '李克勤',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/13.mp3',
                id: '0013'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/14.jpg',
                name: 'Rolling in the Deep',
                author: 'Adele',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/14.m4a',
                id: '0014'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/15.jpg',
                name: '海阔天空',
                author: 'Beyond',
                url: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/15.m4a',
                id: '0015'
            }
        ];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: SongCard_Params) {
        if (params.columnIndex !== undefined) {
            this.columnIndex = params.columnIndex;
        }
        if (params.showList !== undefined) {
            this.showList = params.showList;
        }
        if (params.songs !== undefined) {
            this.songs = params.songs;
        }
    }
    updateStateVars(params: SongCard_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__showList.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__showList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private columnIndex: number;
    private __showList: ObservedPropertyObjectPU<songItemType[]>;
    get showList() {
        return this.__showList.get();
    }
    set showList(newValue: songItemType[]) {
        this.__showList.set(newValue);
    }
    private songs: songItemType[];
    aboutToAppear() {
        this.showList = this.songs.map(item => new songItemTypeModel(item))
            .sort(() => Math.random() - 0.5);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create({ space: 12 });
            List.debugLine("entry/src/main/ets/views/Mine.ets(227:5)", "entry");
            List.width('100%');
            List.height('100%');
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.debugLine("entry/src/main/ets/views/Mine.ets(229:9)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Stack.create();
                            Stack.debugLine("entry/src/main/ets/views/Mine.ets(230:11)", "entry");
                            Stack.width('100%');
                            Stack.aspectRatio(1);
                            Stack.borderRadius(8);
                            Stack.clip(true);
                        }, Stack);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Image.create(item.img);
                            Image.debugLine("entry/src/main/ets/views/Mine.ets(231:13)", "entry");
                            Image.width('100%');
                        }, Image);
                        Stack.pop();
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.showList, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        List.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
if (getPreviewComponentFlag()) {
    storePreviewComponents(1, "Mine", new Mine(undefined, {}));
    previewComponent();
}
else {
}
