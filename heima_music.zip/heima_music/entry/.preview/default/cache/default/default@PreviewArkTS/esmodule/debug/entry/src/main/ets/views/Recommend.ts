if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Recommend_Params {
    swiperList?: string[];
    dailyRecommend?: recommendDailyType[];
    recommendList?: recommendListType[];
}
interface recommendDailyType {
    img: string; // 图片
    title: string; // 简介文字
    type: string; // 标题文字
    top: string; // 标题背景色
    bottom: string; // 简介背景色
}
interface recommendListType {
    img: string; // 图片
    title: string; // 标题文字
    count: string; // 播放数量
}
class Recommend extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__swiperList = new ObservedPropertyObjectPU([
            "http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/banner1.png",
            "http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/banner2.png",
            "http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/banner3.png",
            "http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/banner4.png",
            "http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/banner5.png"
        ]
        // 每日推荐数据
        , this, "swiperList");
        this.__dailyRecommend = new ObservedPropertyObjectPU([
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/recommend1.png',
                title: '每日推荐 | 今天从《不得不爱》听起 | 私人雷达',
                type: '每日推荐',
                top: '#660000',
                bottom: '#382e2f'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/recommend2.png',
                title: '从 [Nothing on Me] 开启无限漫游',
                type: '私人漫游',
                top: '#382e2f',
                bottom: '#a37862'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/recommend3.png',
                title: '每日推荐 | 今天从《不得不爱》听起 | 私人雷达',
                type: '华语流行',
                top: '#a37862',
                bottom: '#174847'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/recommend4.png',
                title: '每日推荐 | 今天从《不得不爱》听起 | 私人雷达',
                type: '私人雷达',
                top: '#174847',
                bottom: '#174847'
            }
        ]
        // 推荐歌单数据
        , this, "dailyRecommend");
        this.__recommendList = new ObservedPropertyObjectPU([
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/list1.jpg',
                title: '每日推荐 | 今天从《不得不爱》听起 | 私人雷达',
                count: '270.9万'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/list2.jpg',
                title: 'Yasuo和更多好听的 | 华语私人雷达 | 回忆8090',
                count: '476.1万'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/list3.jpg',
                title: 'Trap Remix丨当欧美热单遇上毒性低音',
                count: '186.3万'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/list4.jpg',
                title: '满级人类进化之路必备BGM | 根本停不下来',
                count: '186.3万'
            },
            {
                img: 'http://yjy-teach-oss.oss-cn-beijing.aliyuncs.com/HeimaCloudMusic/list5.jpg',
                title: '认真去聆听这个世界的每一分每一秒 (强烈推荐)',
                count: '362.8万'
            }
        ]
        // 搜索框
        , this, "recommendList");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Recommend_Params) {
        if (params.swiperList !== undefined) {
            this.swiperList = params.swiperList;
        }
        if (params.dailyRecommend !== undefined) {
            this.dailyRecommend = params.dailyRecommend;
        }
        if (params.recommendList !== undefined) {
            this.recommendList = params.recommendList;
        }
    }
    updateStateVars(params: Recommend_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__swiperList.purgeDependencyOnElmtId(rmElmtId);
        this.__dailyRecommend.purgeDependencyOnElmtId(rmElmtId);
        this.__recommendList.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__swiperList.aboutToBeDeleted();
        this.__dailyRecommend.aboutToBeDeleted();
        this.__recommendList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 轮播图数据
    private __swiperList: ObservedPropertyObjectPU<string[]>;
    get swiperList() {
        return this.__swiperList.get();
    }
    set swiperList(newValue: string[]) {
        this.__swiperList.set(newValue);
    }
    // 每日推荐数据
    private __dailyRecommend: ObservedPropertyObjectPU<recommendDailyType[]>;
    get dailyRecommend() {
        return this.__dailyRecommend.get();
    }
    set dailyRecommend(newValue: recommendDailyType[]) {
        this.__dailyRecommend.set(newValue);
    }
    // 推荐歌单数据
    private __recommendList: ObservedPropertyObjectPU<recommendListType[]>;
    get recommendList() {
        return this.__recommendList.get();
    }
    set recommendList(newValue: recommendListType[]) {
        this.__recommendList.set(newValue);
    }
    // 搜索框
    // @Builder 可以理解为一个特殊的函数，用于定义结构
    searchBuilder(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/views/Recommend.ets(92:5)", "entry");
            Row.padding(10);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/views/Recommend.ets(93:7)", "entry");
            Row.width('100%');
            Row.height(40);
            Row.backgroundColor('#2d2a29');
            Row.borderRadius(20);
            Row.padding({ left: 10, right: 10 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777236, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/views/Recommend.ets(94:9)", "entry");
            Image.width(20);
            Image.fillColor('#7e7e7c');
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('只因你太美🔥');
            Text.debugLine("entry/src/main/ets/views/Recommend.ets(97:9)", "entry");
            Text.fontColor('#7e7e7c');
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777246, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/views/Recommend.ets(100:9)", "entry");
            Image.width(20);
            Image.fillColor('#7e7e7c');
        }, Image);
        Row.pop();
        Row.pop();
    }
    // 轮播图
    swiperBuilder(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // Swiper 滑动容器组件，常用于制作轮播图效果
            Swiper.create();
            Swiper.debugLine("entry/src/main/ets/views/Recommend.ets(117:5)", "entry");
            // Swiper 滑动容器组件，常用于制作轮播图效果
            Swiper.width('100%');
            // Swiper 滑动容器组件，常用于制作轮播图效果
            Swiper.autoPlay(true);
        }, Swiper);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create(item);
                    Image.debugLine("entry/src/main/ets/views/Recommend.ets(119:9)", "entry");
                    Image.borderRadius(8);
                    Image.width('100%');
                    Image.aspectRatio(720 / 300);
                }, Image);
            };
            this.forEachUpdateFunction(elmtId, this.swiperList, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        // Swiper 滑动容器组件，常用于制作轮播图效果
        Swiper.pop();
    }
    // 每日推荐
    dailyBuilder(parent = null) {
        // 标题
        this.titleBuilder.bind(this)('每日推荐', parent ? parent : this);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // Scroll 滚动容器
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/views/Recommend.ets(135:5)", "entry");
            // Scroll 滚动容器
            Scroll.scrollable(ScrollDirection.Horizontal);
            // Scroll 滚动容器
            Scroll.scrollBar(BarState.Off);
            // Scroll 滚动容器
            Scroll.edgeEffect(EdgeEffect.Spring);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // Scroll 只能有一个子组件
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/views/Recommend.ets(137:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/views/Recommend.ets(139:11)", "entry");
                    Column.width('40%');
                    Column.borderRadius(8);
                    Column.clip(true);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.type);
                    Text.debugLine("entry/src/main/ets/views/Recommend.ets(140:13)", "entry");
                    Text.width('100%');
                    Text.backgroundColor(item.top);
                    Text.padding(8);
                    Text.fontColor('#fff');
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create(item.img);
                    Image.debugLine("entry/src/main/ets/views/Recommend.ets(145:13)", "entry");
                    Image.width('100%');
                    Image.aspectRatio(1);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.title);
                    Text.debugLine("entry/src/main/ets/views/Recommend.ets(148:13)", "entry");
                    Text.width('100%');
                    Text.backgroundColor(item.bottom);
                    Text.padding(8);
                    Text.fontColor('#fff');
                    Text.fontSize(14);
                    Text.lineHeight(18);
                    Text.maxLines(2);
                    Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                }, Text);
                Text.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, this.dailyRecommend, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        // Scroll 只能有一个子组件
        Row.pop();
        // Scroll 滚动容器
        Scroll.pop();
    }
    songBuilder(parent = null) {
        this.titleBuilder.bind(this)('推荐歌单', parent ? parent : this);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/views/Recommend.ets(172:5)", "entry");
            Scroll.scrollable(ScrollDirection.Horizontal);
            Scroll.scrollBar(BarState.Off);
            Scroll.edgeEffect(EdgeEffect.Spring);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/views/Recommend.ets(173:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create({ space: 10 });
                    Column.debugLine("entry/src/main/ets/views/Recommend.ets(175:11)", "entry");
                    Column.width('30%');
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 层叠布局
                    Stack.create({ alignContent: Alignment.TopStart });
                    Stack.debugLine("entry/src/main/ets/views/Recommend.ets(177:13)", "entry");
                }, Stack);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create(item.img);
                    Image.debugLine("entry/src/main/ets/views/Recommend.ets(178:15)", "entry");
                    Image.width('100%');
                    Image.aspectRatio(1);
                    Image.borderRadius(10);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.count);
                    Text.debugLine("entry/src/main/ets/views/Recommend.ets(182:15)", "entry");
                    Text.fontColor('#fff');
                    Text.margin(5);
                }, Text);
                Text.pop();
                // 层叠布局
                Stack.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.title);
                    Text.debugLine("entry/src/main/ets/views/Recommend.ets(187:13)", "entry");
                    Text.fontColor('#fff');
                    Text.maxLines(2);
                    Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                }, Text);
                Text.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, this.recommendList, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        Row.pop();
        Scroll.pop();
    }
    // 公共标题
    titleBuilder(title: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/views/Recommend.ets(204:5)", "entry");
            Row.width('100%');
            Row.padding(8);
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(title);
            Text.debugLine("entry/src/main/ets/views/Recommend.ets(205:7)", "entry");
            Text.fontColor('#fff');
            Text.fontWeight(700);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777230, "type": 20000, params: [], "bundleName": "com.itheima.hm_music", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/views/Recommend.ets(208:7)", "entry");
            Image.width(22);
            Image.fillColor('#fff');
        }, Image);
        Row.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // Scroll 让内容超出一屏后，可以滚动
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/views/Recommend.ets(219:5)", "entry");
            // Scroll 让内容超出一屏后，可以滚动
            Scroll.width('100%');
            // Scroll 让内容超出一屏后，可以滚动
            Scroll.height('100%');
            // Scroll 让内容超出一屏后，可以滚动
            Scroll.scrollable(ScrollDirection.Vertical);
            // Scroll 让内容超出一屏后，可以滚动
            Scroll.edgeEffect(EdgeEffect.Spring);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // Column/Row 组件都是无滚动条的
            Column.create();
            Column.debugLine("entry/src/main/ets/views/Recommend.ets(221:7)", "entry");
            // Column/Row 组件都是无滚动条的
            Column.constraintSize({ minHeight: '100%' });
            // Column/Row 组件都是无滚动条的
            Column.padding({ left: 10, right: 10 });
        }, Column);
        // 搜索框
        this.searchBuilder.bind(this)(this);
        // 轮播图
        this.swiperBuilder.bind(this)(this);
        // 每日推荐
        this.dailyBuilder.bind(this)(this);
        // 推荐歌单
        this.songBuilder.bind(this)(this);
        // Column/Row 组件都是无滚动条的
        Column.pop();
        // Scroll 让内容超出一屏后，可以滚动
        Scroll.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
// 默认导出，可通过 import 导入
export default Recommend;
if (getPreviewComponentFlag()) {
    storePreviewComponents(1, "Recommend", new Recommend(undefined, {}));
    previewComponent();
}
else {
}
